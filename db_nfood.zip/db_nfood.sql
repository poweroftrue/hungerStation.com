-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 12, 2016 at 05:21 PM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 5.6.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_nfood`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `admin_id` int(3) NOT NULL,
  `admin_name` varchar(100) NOT NULL,
  `email_address` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`admin_id`, `admin_name`, `email_address`, `password`) VALUES
(4, 'Nejum Islam', 'nejum.islam@gmail.com', '4297f44b13955235245b2497399d7a93'),
(10, 'Sagor', 'sagor@hotmail.com', 'e10adc3949ba59abbe56e057f20f883e');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE `tbl_category` (
  `category_id` int(3) NOT NULL,
  `category_name` varchar(100) NOT NULL,
  `category_description` text NOT NULL,
  `publication_status` tinyint(1) NOT NULL DEFAULT '1',
  `deletion_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`category_id`, `category_name`, `category_description`, `publication_status`, `deletion_status`) VALUES
(1, 'MENU', '', 1, 0),
(2, 'SHOP', '', 1, 1),
(3, 'RESERVATION', '', 1, 1),
(4, 'GALLERY', '', 1, 1),
(5, 'JOURNAL', '', 1, 1),
(6, 'CONTACT', '', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer`
--

CREATE TABLE `tbl_customer` (
  `customer_id` int(11) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email_address` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `phone_number` varchar(100) NOT NULL,
  `address` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_customer`
--

INSERT INTO `tbl_customer` (`customer_id`, `first_name`, `last_name`, `email_address`, `password`, `phone_number`, `address`) VALUES
(7, 'Rasel', 'Islam', 'rasel@nfood.com', '4297f44b13955235245b2497399d7a93', '01611787808', 'badda'),
(8, 'Abdur', 'Rahim', 'rahim@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '123456', 'dhaka'),
(9, 'Abdur', 'Rahim', 'rahim@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '123456', 'mirpur');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order`
--

CREATE TABLE `tbl_order` (
  `order_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `shipping_id` int(11) NOT NULL,
  `order_total` float(10,2) NOT NULL,
  `order_status` varchar(50) NOT NULL DEFAULT 'pending',
  `order_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_order`
--

INSERT INTO `tbl_order` (`order_id`, `customer_id`, `shipping_id`, `order_total`, `order_status`, `order_date`) VALUES
(5, 7, 4, 4082.50, 'pending', '2016-12-05 16:14:12'),
(6, 8, 5, 1012.00, 'pending', '2016-12-08 06:54:54'),
(7, 9, 6, 644.00, 'pending', '2016-12-08 07:37:53'),
(8, 9, 6, 644.00, 'pending', '2016-12-08 09:01:31');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order_details`
--

CREATE TABLE `tbl_order_details` (
  `order_details_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `product_price` float(10,2) NOT NULL,
  `product_quantity` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_order_details`
--

INSERT INTO `tbl_order_details` (`order_details_id`, `order_id`, `product_id`, `product_name`, `product_price`, `product_quantity`) VALUES
(1, 5, 12, 'Steak Skewer & Eggs Skillet', 550.00, 5),
(2, 5, 45, 'Pumpkin Pie', 400.00, 2),
(3, 6, 23, 'Box-Lunch', 440.00, 2),
(4, 7, 11, 'NEW! Honey Jalapeno Bacon Slam', 560.00, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_payment`
--

CREATE TABLE `tbl_payment` (
  `payment_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `payment_type` varchar(50) NOT NULL,
  `payment_status` varchar(50) NOT NULL DEFAULT 'pending',
  `payment_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_payment`
--

INSERT INTO `tbl_payment` (`payment_id`, `order_id`, `payment_type`, `payment_status`, `payment_date`) VALUES
(4, 5, 'cash_on_delivery', 'pending', '2016-12-05 16:14:12'),
(5, 6, 'cash_on_delivery', 'pending', '2016-12-08 06:54:54'),
(6, 7, 'cash_on_delivery', 'pending', '2016-12-08 07:37:53'),
(7, 8, 'cash_on_delivery', 'pending', '2016-12-08 09:01:31');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product`
--

CREATE TABLE `tbl_product` (
  `product_id` int(11) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `category_id` int(3) NOT NULL,
  `sub_category_id` int(3) NOT NULL,
  `product_price` float(10,2) NOT NULL,
  `product_quantity` int(5) NOT NULL,
  `product_short_description` text NOT NULL,
  `product_long_description` text NOT NULL,
  `product_image` text NOT NULL,
  `publication_status` tinyint(1) NOT NULL,
  `deletion_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_product`
--

INSERT INTO `tbl_product` (`product_id`, `product_name`, `category_id`, `sub_category_id`, `product_price`, `product_quantity`, `product_short_description`, `product_long_description`, `product_image`, `publication_status`, `deletion_status`) VALUES
(1, 'NEW! Pumpkin Cream Pancake Breakfast', 1, 1, 550.00, 100, 'Two new fluffy pumpkin pancakes layered and topped with pumpkin cream. Served with two eggs and hash browns, plus your choice of two strips of bacon or two sausage links.\r\n', '', '../assets/images/product_images/1.jpg', 1, 0),
(9, 'NEW! Super Blackberry Pancake', 1, 1, 550.00, 200, 'Two hearty wheat pancakes topped with blackberry sauce, fresh blackberries and flaxseed streusel. Served with two eggs and hash browns, plus your choice of two strips of bacon or two sausage links.\r\n', '', '../assets/images/product_images/4.jpg', 1, 0),
(10, 'NEW! Sticky Bun Pancake Breakfast', 1, 1, 540.00, 100, 'Cinnamon sauce and cream cheese icing drizzled over two new fluffy buttermilk pancakes with glazed pecans cooked inside. Served with two eggs and hash browns, plus your choice of two strips of bacon or two sausage links.\r\n', '', '../assets/images/product_images/5.jpg', 1, 0),
(11, 'NEW! Honey Jalapeno Bacon Slam', 1, 1, 560.00, 100, 'Two strips of our new premium, thick-cut honey jalapeÃ±o bacon, two eggs, two new fluffy buttermilk pancakes and hash browns.\r\n', '', '../assets/images/product_images/6.jpg', 1, 0),
(12, 'Steak Skewer & Eggs Skillet', 1, 1, 550.00, 100, 'A grilled sirloin steak skewer atop fire-roasted bell peppers and onions, mushrooms and seasoned red-skinned potatoes. Topped with a sweet bourbon sauce and two eggs.\r\n', '', '../assets/images/product_images/7.jpg', 1, 0),
(13, ' Grand Slam', 1, 1, 560.00, 100, 'Just ask  for the Original Grand SlamÂ® and get two new fluffy buttermilk pancakes, two eggs, two bacon strips and two sausage links.Â \r\n', '', '../assets/images/product_images/8.jpg', 1, 0),
(14, 'All-American Slam', 1, 1, 540.00, 100, 'Three scrambled eggs with Cheddar cheese, two bacon strips and two sausage links, plus hash browns and choice of bread.\r\n', '', '../assets/images/product_images/9.jpg', 1, 0),
(15, 'The Grand Slamwich', 1, 1, 570.00, 100, 'Two scrambled eggs, crumbled sausage, bacon, shaved ham and American cheese on potato bread grilled with a maple spice spread. Served with hash browns.\r\n', '', '../assets/images/product_images/10.jpg', 1, 0),
(16, 'Lunch with methi roti', 1, 4, 560.00, 100, 'Lunch with methi roti or thepla, kadai paneer, dal tadka, steamed rice, papad, pickle, dahi.\r\n', '', '../assets/images/product_images/11.jpg', 1, 0),
(17, 'NEW! Rudolphâ„¢ Pancake Breakfast', 1, 1, 540.00, 100, 'Our new fluffy buttermilk pancake with turkey bacon antlers, topped with vanilla cream and chocolate eyes and nose. Served with two eggs and hash browns.\r\n', '', '../assets/images/product_images/2.jpg', 1, 0),
(18, 'Beef Biryani', 1, 4, 440.00, 0, 'Beef Biryani', '', '../assets/images/product_images/12.jpg', 1, 0),
(19, 'Beef Curry', 1, 4, 350.00, 100, 'Beef Curry', '', '../assets/images/product_images/13.jpg', 1, 0),
(20, 'Beef Khichuri', 1, 4, 340.00, 0, 'Beef Khichuri', '', '../assets/images/product_images/14.jpg', 1, 0),
(21, 'Chicken Biryani', 1, 4, 340.00, 100, 'Chicken Biryani', '', '../assets/images/product_images/Chicken-Biryani.jpg', 1, 0),
(22, 'Chicken Khichuri', 1, 4, 550.00, 0, 'Chicken Khichuri', '', '../assets/images/product_images/Chicken-Khichuri.jpg', 1, 0),
(23, 'Box-Lunch', 1, 4, 440.00, 0, 'Box-Lunch', '', '../assets/images/product_images/Box-Lunch.jpg', 1, 0),
(24, 'Fish Curry', 1, 4, 320.00, 0, 'Fish Curry', '', '../assets/images/product_images/Fish-Curry.jpg', 1, 0),
(25, 'Salted Caramel & Banana Cream Pancake', 1, 1, 560.00, 100, 'Two new fluffy buttermilk pancakes with shortbread pieces cooked inside, layered with vanilla cream and topped with fresh bananas, warm salted caramel sauce and even more shortbread pieces. Served with two eggs and hash browns, plus your choice of two strips of bacon or two sausage links.\r\n', '', '../assets/images/product_images/3.jpg', 1, 0),
(26, 'Hilsha Khichuri', 1, 4, 540.00, 100, 'Hilsha Khichuri', '', '../assets/images/product_images/Hilsha-Khichuri.jpg', 1, 0),
(27, 'Mixed lunch', 1, 4, 450.00, 100, 'Mixed lunch', '', '../assets/images/product_images/Mixed-lunch.jpg', 1, 0),
(28, 'Mutton Curry', 1, 4, 450.00, 100, 'Mutton Curry', '', '../assets/images/product_images/Mutton-Curry.jpg', 1, 0),
(29, 'Mutton Khichdi', 1, 4, 560.00, 100, 'Mutton Khichdi', '', '../assets/images/product_images/Mutton-Khichdi.png', 1, 0),
(30, 'Dal Vath', 1, 4, 120.00, 100, 'Mutton Khichdi', '', '../assets/images/product_images/Dal-vat.jpg', 1, 0),
(31, 'Vegetable Biryani', 1, 4, 230.00, 100, 'Vegetable Biryani', '', '../assets/images/product_images/Vegetable-Biryani.jpg', 1, 0),
(32, 'NEW! Steak Skewer Skillet', 1, 4, 340.00, 100, 'A grilled sirloin steak skewer atop fire-roasted bell peppers and onions, zucchini and squash, and seasoned red-skinned potatoes, then topped with a sweet bourbon glaze.\r\n', '', '../assets/images/product_images/NEW-Steak Skewer-Skillet.jpg', 1, 0),
(33, 'NEW! Wild Alaska Salmon Skillet', 1, 4, 540.00, 100, 'A grilled wild-caught Alaska salmon fillet seasoned with a delicious blend of garlic and herbs. Served atop seasoned red-skinned potatoes, fresh spinach, broccoli, sautÃ©ed mushrooms and grape tomatoes.\r\n', '', '../assets/images/product_images/NEW-Wild-Alaska-Salmon-Skillet.jpg', 1, 0),
(34, 'Turkey & Dressing Dinner', 1, 4, 430.00, 100, 'Tender carved turkey breast, savory stuffing, turkey gravy and cranberry sauce. Served with your choice of two sides and dinner bread. Also available in a Senior portion\r\n', '', '../assets/images/product_images/Turkey-&-Dressing-Dinner.jpg', 1, 0),
(35, 'Brooklyn Spaghetti & Meatballs', 1, 4, 340.00, 100, 'Three seasoned meatballs atop a bed of pasta covered in a rich, meaty tomato sauce. Served with a side of shredded Italian cheeses and garlic toast.\r\n', '', '../assets/images/product_images/Brooklyn- Spaghetti-&-Meatballs.jpg', 1, 0),
(36, 'Bourbon Chicken Skillet', 1, 4, 450.00, 100, 'Two grilled seasoned chicken breasts covered with a delicious sweet bourbon glaze, topped with mushrooms and fire-roasted bell peppers and onions, all atop broccoli and seasoned red-skinned potatoes.\r\n', '', '../assets/images/product_images/Bourbon-Chicken-Skillet.jpg', 1, 0),
(37, 'Chicken Strips', 1, 4, 450.00, 100, 'Four spicy, golden brown breaded chicken strips served with a dipping sauce, your choice of two sides and dinner bread.\r\n', '', '../assets/images/product_images/Chicken-Strips.jpg', 1, 0),
(38, 'Slow-Cooked Pot Roast', 1, 4, 450.00, 100, 'Our slow-cooked pot roast, creamy mashed potatoes and herb-roasted carrots, celery, mushrooms and onions atop garlic toast and covered in rich gravy.\r\n', '', '../assets/images/product_images/Slow-Cooked-Pot-Roast.jpg', 1, 0),
(39, 'Fish & Chips', 1, 4, 560.00, 100, 'Two wild-caught white fish fillets fried golden-brown and served with wavy-cut French fries. Served with tartar sauce and your choice of one side and dinner bread.\r\n', '', '../assets/images/product_images/Fish-Chips.jpg', 1, 0),
(40, 'Tilapia Ranchero', 1, 4, 430.00, 100, 'A seasoned white fish fillet grilled and topped with freshly made pico de gallo and fresh avocado. Served with your choice of two sides and dinner bread.Â Gluten Free when you choose two Gluten Free sides and the Gluten Free English Muffin.\r\n', '', '../assets/images/product_images/Tilapia-Ranchero.jpg', 1, 0),
(41, 'T-Bone Steak', 1, 4, 340.00, 100, 'A tender 13 oz. seasoned T-Bone steak with your choice of two sides and dinner bread.Â Gluten Free when you choose two Gluten Free sides and the Gluten Free English Muffin.\r\n', '', '../assets/images/product_images/T-Bone-Steak.jpg', 1, 0),
(42, 'NEW! Red Velvet Pancake Puppies', 1, 5, 250.00, 100, 'Six Red Velvet Pancake PuppiesÂ® made with white chocolate chips and tossed in powdered sugar. Served with a side of cream cheese icing for dipping.\r\n', '', '../assets/images/product_images/NEW-Red-Velvet-Pancake-Puppies.jpg', 1, 0),
(43, 'NEW! Holiday Cookie Milk Shake', 1, 5, 240.00, 100, 'Our creamy, hand-dipped milk shake is made with premium vanilla ice cream blended with cookie butter, then topped with whipped cream and shortbread pieces. Served with a little extra in the tin.\r\n', '', '../assets/images/product_images/NEW-Holiday-Cookie-Milk-Shake.jpg', 1, 0),
(44, 'Pecan Pie', 1, 5, 300.00, 100, 'End your meal with a slice of Pecan Pie. A seasonal favorite.\r\n', '', '../assets/images/product_images/Pumpkin-Pie.jpg', 1, 0),
(45, 'Pumpkin Pie', 1, 5, 400.00, 100, 'End your meal with a slice of Pumpkin Pie for only . A seasonal favorite.\r\n', '', '../assets/images/product_images/Pecan-Pie.png', 1, 0),
(46, ' Sundae', 1, 5, 500.00, 100, 'Pick Two Scoops Of Premium Ice Cream: \r\nVanilla, Chocolate or Strawberry.\r\nPick A Topping:\r\nHot Fudge, Caramel or Strawberry.\r\nPick A Crunch:\r\nOREO Cookie Pieces, Glazed Pecans or Chopped Nuts.\r\n', '', '../assets/images/product_images/Build-Your-Own-Sundae.jpg', 1, 0),
(47, 'Milk Shakes', 1, 5, 230.00, 100, 'Enjoy a full glass of our thick, creamy, hand-dipped milk shakes made with premium ice cream, plus a little extra in the tin. Choose from Chocolate Peanut Butter, Vanilla, Chocolate, Strawberry or OREO\r\n', '', '../assets/images/product_images/Milk-Shakes.jpg', 1, 0),
(48, 'Caramel Apple Pie Crisp', 1, 5, 350.00, 0, 'Warm apple crisp topped with premium vanilla ice cream and caramel sauce, then sprinkled with powdered sugar.\r\n', '', '../assets/images/product_images/Caramel-Apple-Pie-Crisp.jpg', 1, 0),
(49, 'Banana Split', 1, 5, 250.00, 100, 'Fresh banana and three generous scoops of premium ice cream with caramel, hot fudge and strawberry topping, whipped cream and chopped nuts.\r\n', '', '../assets/images/product_images/Banana-Split.jpg', 1, 0),
(50, 'Chocolate Lava Cake', 1, 5, 340.00, 100, 'A warm, rich chocolate cake filled with molten chocolate and topped with premium vanilla ice cream.\r\n', '', '../assets/images/product_images/Chocolate-Lava-Cake.jpg', 1, 0),
(51, 'Cheesecake', 1, 5, 230.00, 100, 'Cheesecake with a graham cracker crust served plain or with strawberry topping and whipped cream.\r\n', '', '../assets/images/product_images/Cheesecake.jpg', 1, 0),
(52, 'NEW! Loaded Bacon Cheddar Tots', 1, 7, 120.00, 100, 'Ten of our house-made crispy tots made with shredded potatoes, bacon and Cheddar cheese. Topped with Pepper Jack queso, jalapeÃ±os, bacon, Cheddar cheese and sour cream.\r\n', '', '../assets/images/product_images/Loaded-Bacon-Cheddar-Tots.jpg', 1, 0),
(53, 'NEW! Bacon Cheddar Tots', 1, 7, 230.00, 100, 'Ten of our house-made crispy tots with shredded potatoes, bacon and Cheddar cheese. Served with sour cream.\r\n', '', '../assets/images/product_images/NEW-Bacon-Cheddar-Tots.jpg', 1, 0),
(54, 'Sampler', 1, 7, 120.00, 100, 'Pick three and make it your own. Served with your choice of dipping sauces.\r\n', '', '../assets/images/product_images/Build-Your-Own-Sampler.jpg', 1, 0),
(55, 'Chicken & Sausage Quesadilla', 1, 7, 120.00, 100, 'Roasted seasoned chicken, crumbled sausage, fire-roasted bell peppers and onions, melted American cheese and freshly made pico de gallo fill a flour tortilla. Served with a side of ranch dressing.\r\n', '', '../assets/images/product_images/Chicken-Sausage-Quesadilla.jpg', 1, 0),
(56, 'Mozzarella Cheese Sticks', 1, 7, 200.00, 100, 'Golden-fried with a side of dipping sauce.\r\n', '', '../assets/images/product_images/Mozzarella-Cheese-Sticks.jpg', 1, 0),
(57, 'Zesty Nachos', 1, 7, 120.00, 100, 'Our tortilla chips are cooked fresh to order. Topped with Pepper Jack queso, shredded Cheddar cheese, seasoned nacho meat, freshly made pico de gallo and sour cream. Also served as a half size.\r\n', '', '../assets/images/product_images/Zesty-Nachos.jpg', 1, 0),
(58, 'Chicken Strips', 1, 7, 120.00, 100, 'Spicy, golden brown breaded chicken strips tossed in your choice of Sweet & Tangy BBQ or Buffalo sauce. Served with celery sticks and your choice of dipping sauce.\r\n', '', '../assets/images/product_images/Chicken-Strips-spicy.jpg', 1, 0),
(59, 'NEW! Hearty 3-Meat Chili', 1, 8, 230.00, 100, 'Our hearty chili is made in-house with shredded beef, ground beef and crumbled chorizo sausage topped with Cheddar cheese and a dollop of sour cream.\r\n', '', '../assets/images/product_images/NEW-Hearty-3-Meat-Chili.jpg', 1, 0),
(60, 'Prime Rib Cobb Salad', 1, 8, 230.00, 100, 'Tender prime rib, bacon, fresh avocado, grape tomatoes, Cheddar cheese, hard-boiled egg and potato sticks atop a bed of spring mix. Served with the dressing of your choice. Also available: Grilled Chicken Cobb Salad or Fried Chicken Strips Cobb Salad.\r\n', '', '../assets/images/product_images/Prime-Rib-Cobb-Salad.jpg', 1, 0),
(61, 'Cranberry Apple Chicken Salad', 1, 8, 240.00, 100, 'Grilled seasoned chicken breast, glazed pecans, apple slices and dried cranberries atop a bed of spring mix. Served with balsamic vinaigrette.\r\n', '', '../assets/images/product_images/Cranberry-Apple-Chicken-Salad.jpg', 1, 0),
(62, 'Avocado Chicken Caesar Salad', 1, 8, 230.00, 100, 'Grilled seasoned chicken breast, fresh avocado, crisp bacon crumbles and shredded Italian cheeses on top of fresh romaine lettuce and tossed with Caesar dressing.\r\n', '', '../assets/images/product_images/Avocado-Chicken-CaesarSalad.jpg', 1, 0),
(63, 'Vegetable Beef Soup', 1, 8, 250.00, 100, 'Our soups are kettle-cooked to be rich and hearty. Available from 11 am to 10 pm on Monday and Tuesday.\r\n', '', '../assets/images/product_images/Vegetable-Beef-Soup.jpg', 1, 0),
(64, 'Loaded Baked Potato Soup', 1, 8, 240.00, 100, 'Our soups are kettle-cooked to be rich and hearty. Available from 11 am to 10 pm on Wednesday and Thursday.\r\n', '', '../assets/images/product_images/Loaded-Baked-Potato-Soup.jpg', 1, 0),
(65, 'Broccoli & Cheddar Soup', 1, 8, 340.00, 100, 'Our soups are kettle-cooked to be rich and hearty. Available from 11 am to 10 pm on Saturday and Sunday.\r\n', '', '../assets/images/product_images/Broccoli-Cheddar-Soup.jpg', 1, 0),
(66, 'Chicken Noodle Soup', 1, 8, 230.00, 100, 'Our soups are kettle-cooked to be rich and hearty. Available from 11 am to 10 pm every day.\r\n', '', '../assets/images/product_images/Chicken-Noodle-Soup.jpg', 1, 0),
(67, 'Clam Chowder', 1, 8, 320.00, 100, 'Our soups are kettle-cooked to be rich and hearty. Available from 11 am to 10 pm on Friday.\r\n', '', '../assets/images/product_images/Clam-Chowder.jpg', 1, 0),
(69, 'Premium Lemonades', 1, 9, 320.00, 100, 'Made with real lemons for that all-natural taste. Free refills. Â \r\n', '', '../assets/images/product_images/Premium-Lemonades.jpg', 1, 0),
(70, 'Juices', 1, 9, 230.00, 100, 'Choose from a variety of juices available.\r\n', '', '../assets/images/product_images/Juices.jpg', 1, 0),
(71, 'Hot Chocolate', 1, 9, 230.00, 100, 'Hot Chocolate\r\n', '', '../assets/images/product_images/Hot-Chocolate.jpg', 1, 0),
(72, 'Soft drinks', 1, 9, 80.00, 100, 'Soft drinks\r\n', '', '../assets/images/product_images/Soft-Drinks.jpg', 1, 0),
(73, 'Iced Cappuccino', 1, 9, 120.00, 100, 'Chill out with our Iced Cappuccino. Relax with an ice-cold take on our classic pick-me-up.\r\n', '', '../assets/images/product_images/Iced-Cappuccino.jpg', 1, 0),
(74, 'Signature Diner Roasts', 1, 9, 120.00, 100, 'Our delicious Signature Diner Roastsâ„¢ come in two coffee blends: MILD and BOLD. So, no matter what your coffee preference is, weâ€™ve got a roast for you. Also available in Decaf.Â New Hazelnut & Vanilla Creamers available.\r\n', '', '../assets/images/product_images/Signature-Diner-Roasts.jpg', 1, 0),
(75, 'NEW! Honey JalapeÃ±o Bacon Sriracha', 1, 6, 230.00, 100, 'A hand-pressed 100% beef patty topped with Cheddar cheese, thick-cut honey jalapeno bacon, jalapenos and creamy Sriracha sauce. Served with lettuce, tomato, red onions and pickles on a brioche bun.\r\n', '', '../assets/images/product_images/NEW-Honey-Jalapeno-Bacon-Sriracha-Burger.jpg', 1, 0),
(76, 'Chicken Philly Melt', 1, 6, 230.00, 100, 'Roasted seasoned chicken, sautÃ©ed mushrooms, fire-roasted bell peppers and onions, shredded Italian cheeses and Pepper Jack queso. Served on a hoagie roll grilled with garlic and herbs.\r\n', '', '../assets/images/product_images/Chicken-Philly-Melt.jpg', 1, 0),
(77, 'Pot Roast Melt', 1, 6, 230.00, 100, 'Slow-cooked pot roast with melted American cheese, mushrooms and caramelized onions on grilled 7-grain bread.\r\n', '', '../assets/images/product_images/Pot-Roast-Melt.jpg', 1, 0),
(78, 'Club Sandwich', 1, 6, 120.00, 100, 'Thinly sliced turkey breast, crisp bacon, lettuce, tomato and mayo on toasted 7-grain bread.\r\n', '', '../assets/images/product_images/Club-Sandwich.jpg', 1, 0),
(79, 'Cali Club Sandwich', 1, 6, 120.00, 100, 'Thinly sliced turkey breast, ham, crisp bacon, Swiss cheese and fresh avocado. Served on toasted 7-grain bread with sun-dried tomato mayo, lettuce and tomato.\r\n', '', '../assets/images/product_images/Cali-Club-Sandwich.jpg', 1, 0),
(80, 'Bourbon Bacon Burger', 1, 6, 250.00, 100, 'A hand-pressed 100% beef patty topped with Cheddar cheese, bacon, sautÃ©ed mushrooms and fire-roasted bell peppers and onions. Served on a Cheddar bun with lettuce, tomato, red onions, pickles and a sweet bourbon sauce.\r\n', '', '../assets/images/product_images/Bourbon-Bacon-Burger.jpg', 1, 0),
(81, 'Prime Rib Philly Melt', 1, 6, 230.00, 100, 'Juicy prime rib, sauteed mushrooms, fire-roasted bell peppers and onions, shredded Italian cheeses and Pepper Jack queso. Served on a hoagie roll grilled with garlic and herbs.\r\n', '', '../assets/images/product_images/Prime-Rib-Philly-Melt.jpg', 1, 0),
(82, 'Chicken Bacon Classic', 1, 6, 230.00, 100, 'Your choice of American, Swiss or Cheddar cheese tops two hand-pressed 100% beef patties. Served with lettuce, tomato, red onions and pickles.\r\n', '', '../assets/images/product_images/Chicken-Bacon-Classic.jpg', 1, 0),
(83, 'NEW! Chili Cheeseburger', 1, 6, 230.00, 100, 'Our new Hearty 3-Meat Chili tops a hand-pressed 100% beef patty and Cheddar cheese. Served with lettuce, tomato, red onions and pickles on a brioche bun.\r\n', '', '../assets/images/product_images/NEW-Chili-Cheeseburger.jpg', 1, 0),
(111, 'Iced Teas', 1, 9, 320.00, 100, 'Try one of our deliciously refreshing Iced Teas. Free refills.\r\n', '', '../assets/images/product_images/Iced-Teas.jpg', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_shipping`
--

CREATE TABLE `tbl_shipping` (
  `shipping_id` int(11) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email_address` varchar(100) NOT NULL,
  `phone_number` varchar(100) NOT NULL,
  `address` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_shipping`
--

INSERT INTO `tbl_shipping` (`shipping_id`, `full_name`, `email_address`, `phone_number`, `address`) VALUES
(4, 'Rasel Islam', 'rasel@nfood.com', '01611787808', 'badda'),
(5, 'Abdur Rahim', 'rahim@gmail.com', '123456', 'dhaka'),
(6, 'Abdur Rahim', 'rahim@gmail.com', '123456', 'mirpur');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_slider`
--

CREATE TABLE `tbl_slider` (
  `slider_id` int(3) NOT NULL,
  `slider_name` varchar(100) NOT NULL,
  `slider_image` text NOT NULL,
  `slider_text` text NOT NULL,
  `slider_offer` text NOT NULL,
  `slider_description` text NOT NULL,
  `publication_status` tinyint(1) NOT NULL,
  `deletion_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_slider`
--

INSERT INTO `tbl_slider` (`slider_id`, `slider_name`, `slider_image`, `slider_text`, `slider_offer`, `slider_description`, `publication_status`, `deletion_status`) VALUES
(4, 'Sweet Time', '../assets/images/slider_images/a-family-eating-pizza-in-restaurant-.jpg', 'With family', 'Get 20% off on lunch', 'Sweet time with family', 1, 0),
(5, 'Fresh', '../assets/images/slider_images/fresh-vegitable.jpg', 'Fresh', 'Get 10% off on Breakfast !', 'Fresh Breakfast', 1, 0),
(6, 'Testy', '../assets/images/slider_images/testy.jpg', 'Testy', 'Get 10% off on Dinner !', 'Testy dinner', 1, 0),
(7, 'Nice Place', '../assets/images/slider_images/denilk-omni-interlocken-hotel-meritage-restaurant.jpg', 'Nice Place', '', '', 1, 0),
(8, 'wonderful', '../assets/images/slider_images/japanisches-Restaurant-Hamburg-3.jpg', 'wonderful', 'wonderful place', '', 1, 0),
(9, 'Family Party', '../assets/images/slider_images/02.jpg', 'Family always special', 'Get 5% off on family party !', 'Perfect place for family party\r\n\r\n', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sub_category`
--

CREATE TABLE `tbl_sub_category` (
  `sub_category_id` int(3) NOT NULL,
  `sub_category_name` varchar(100) NOT NULL,
  `sub_category_description` text NOT NULL,
  `publication_status` tinyint(1) NOT NULL,
  `deletion_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_sub_category`
--

INSERT INTO `tbl_sub_category` (`sub_category_id`, `sub_category_name`, `sub_category_description`, `publication_status`, `deletion_status`) VALUES
(1, 'Breakfast', 'Breakfast', 1, 0),
(4, 'Meals', 'Dinner & Lunch', 1, 0),
(5, 'Desserts', 'Desserts', 1, 0),
(6, 'Burgers & Sandwiches', 'Burgers & Sandwiches', 1, 0),
(7, 'Appetizers', 'Appetizers', 1, 0),
(8, 'Soups & Salads', 'Soups & Salads', 1, 0),
(9, 'Beverages', 'Beverages', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_temp_cart`
--

CREATE TABLE `tbl_temp_cart` (
  `temp_cart_id` int(11) NOT NULL,
  `session_id` varchar(100) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `product_price` float(10,2) NOT NULL,
  `product_quantity` int(5) NOT NULL,
  `product_image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_temp_cart`
--

INSERT INTO `tbl_temp_cart` (`temp_cart_id`, `session_id`, `product_id`, `product_name`, `product_price`, `product_quantity`, `product_image`) VALUES
(1, 'k0g81mf80cdqm2j1ktmjk49oi2', 111, 'Iced Teas', 320.00, 1, '../assets/images/product_images/Iced-Teas.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `tbl_category`
--
ALTER TABLE `tbl_category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `tbl_customer`
--
ALTER TABLE `tbl_customer`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `tbl_order`
--
ALTER TABLE `tbl_order`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `tbl_order_details`
--
ALTER TABLE `tbl_order_details`
  ADD PRIMARY KEY (`order_details_id`);

--
-- Indexes for table `tbl_payment`
--
ALTER TABLE `tbl_payment`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `tbl_product`
--
ALTER TABLE `tbl_product`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `tbl_shipping`
--
ALTER TABLE `tbl_shipping`
  ADD PRIMARY KEY (`shipping_id`);

--
-- Indexes for table `tbl_slider`
--
ALTER TABLE `tbl_slider`
  ADD PRIMARY KEY (`slider_id`);

--
-- Indexes for table `tbl_sub_category`
--
ALTER TABLE `tbl_sub_category`
  ADD PRIMARY KEY (`sub_category_id`);

--
-- Indexes for table `tbl_temp_cart`
--
ALTER TABLE `tbl_temp_cart`
  ADD PRIMARY KEY (`temp_cart_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `admin_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `tbl_category`
--
ALTER TABLE `tbl_category`
  MODIFY `category_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `tbl_customer`
--
ALTER TABLE `tbl_customer`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `tbl_order`
--
ALTER TABLE `tbl_order`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `tbl_order_details`
--
ALTER TABLE `tbl_order_details`
  MODIFY `order_details_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `tbl_payment`
--
ALTER TABLE `tbl_payment`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `tbl_product`
--
ALTER TABLE `tbl_product`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=112;
--
-- AUTO_INCREMENT for table `tbl_shipping`
--
ALTER TABLE `tbl_shipping`
  MODIFY `shipping_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `tbl_slider`
--
ALTER TABLE `tbl_slider`
  MODIFY `slider_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `tbl_sub_category`
--
ALTER TABLE `tbl_sub_category`
  MODIFY `sub_category_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `tbl_temp_cart`
--
ALTER TABLE `tbl_temp_cart`
  MODIFY `temp_cart_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
